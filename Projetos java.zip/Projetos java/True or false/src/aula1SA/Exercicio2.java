package aula1SA;

import javax.swing.JOptionPane;

public class Exercicio2 {

	public static void main(String[] args) {
		
		String nome1 = JOptionPane.showInputDialog("Digite seu nome"); 
		int idade1 = Integer.parseInt(JOptionPane.showInputDialog("Entre com a sua idade"));
		String nome2 = JOptionPane.showInputDialog("Digite seu nome"); 
        int idade2 = Integer.parseInt(JOptionPane.showInputDialog("Entre com a sua idade "));	
		
		
		if (idade1 > idade2) { 
			JOptionPane.showMessageDialog(null, nome1 + " é mais novo");	
		} else {
			JOptionPane.showMessageDialog(null, nome2 + " é mais velho");
		}
	
		
		
		

	
	
	
	
	
	
	
	
	}}