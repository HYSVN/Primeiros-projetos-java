package aula1SA;

import javax.swing.JOptionPane;

public class Exercicio3 {

	public static void main(String[] args) {
		String nome = JOptionPane.showInputDialog("Digite seu nome");
        double altura = Double.parseDouble(JOptionPane.showInputDialog("Digite seu altura"));
        
       
        
        double pesoIdealM= (72.7 * altura) - 58; 
        double pesoIdealF= (62.1 * altura) - 44.7;
        		
        String resposta = JOptionPane.showInputDialog("Qual o seu sexo? (Masculino/Feminino)");
		
		if (resposta.equalsIgnoreCase("Masculino")) { 
			JOptionPane.showMessageDialog(null, nome + "\nSeu peso ideal é: " + altura + pesoIdealM + "kg");	
		} else  {
			JOptionPane.showMessageDialog(null, nome + "\nSeu peso ideal é: " + altura + pesoIdealF + "kg");
	    
		/*if(resposta.equalsIgnoreCase("Masculino")) {
		 * pesoIdeal = (72.7 * altura) - 58; 
        } else {
           pesoIdeal = (62.1 * altura) - 44.7;
        }
        
        maneira mais fácil de fazer. 
        
	
	*/
	
	
	
	
	}}}
