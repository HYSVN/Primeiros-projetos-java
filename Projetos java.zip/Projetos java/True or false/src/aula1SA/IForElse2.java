 package aula1SA;

import javax.swing.JOptionPane;

public class IforElse2 {
	public static void main (String[] args) {

       /* Seleção de candidatos
        *  idade <18 e cursando técnico
        * 
        * && (e) -  || (ou) -  ! (não/negação)
        */
		
		/*int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com a idade"));
		String resposta = JOptionPane.showInputDialog("Está cursando técnico? S ou N?");
		String qi = JOptionPane.showInputDialog("Tem QI? S ou N");
		*/
		
		/* if(idade < 18 && resposta.equalsIgnoreCase("s") ) {
			  JOptionPane.showMessageDialog(null, "Candidato Apto");
		   } else { 
			   JOptionPane.showMessageDialog(null, "Candidato Reprovado");
		  }
		*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/* Estrutura de repetição
         * while e do-while
         */
	
	int repetir = 0;
	do {
		int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com a idade"));
		String resposta = JOptionPane.showInputDialog("Está cursando técnico? S ou N?");
		   if(idade < 18 && resposta.equalsIgnoreCase("s") ) {
			  JOptionPane.showMessageDialog(null, "Candidato Apto");
		   } else if (idade >= 18 && resposta.equalsIgnoreCase("n") ) {
			   JOptionPane.showMessageDialog(null, "Candidato Reprovado pela idade e curso");
		   }  else if (idade >= 18 && resposta.equalsIgnoreCase("n") ) {
				   JOptionPane.showMessageDialog(null, "Candidato Reprovado pelo curso:");
		   }  else if (idade >= 18 && resposta.equalsIgnoreCase("n") ) {
			       JOptionPane.showMessageDialog(null, "Candidato Reprovado pela idade:" + idade);
	}
	
	 repetir = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?" , "Sair", JOptionPane.YES_NO_CANCEL_OPTION);
	} while (repetir == 0 || repetir == 2);
	JOptionPane.showMessageDialog(null, "Programa Encerrado");
	
	
	
	//JOptionPane.YES_NO_OPTION Sim ou Não.
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}