package aula1SA;

import javax.swing.JOptionPane;

public class Exercicio4 {
   public static void main (String [] args) {

   String nomeDoProduto = JOptionPane.showInputDialog("Nome do produto");
   
   double preco = Double.parseDouble(JOptionPane.showInputDialog("Entre com o valor do produto"));
   double reajuste = 0;
   double precoNovo= 0;
   
   
   
   
   if (preco <= 1000) {
		reajuste = preco * 0.2;
	} else if(preco <= 2000) {
		reajuste = preco * 0.1;
	
	}
		
	precoNovo = reajuste + preco;
	
	
	
	JOptionPane.showMessageDialog(null, "Nome do Produto:  "      + nomeDoProduto + 
										"\nPreço do Produto: R$ "   + preco         +  		  
										"\nReajuste: R$ "           + reajuste      +
										"\nPreço Novo: R$ "         + precoNovo);
   
	
   
   
   
   
   
   
   
   
   
   
   
   
   }}
