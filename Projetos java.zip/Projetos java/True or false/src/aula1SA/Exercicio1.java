package aula1SA;

import javax.swing.JOptionPane;

public class Exercicio1 {
	public static void main(String[] args) {
	
	
		int numero1 = Integer.parseInt(JOptionPane.showInputDialog("Entre com o primeiro número")); 
		int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Entre com o segundo número"));
		
		if (numero1 >=numero2) {
			JOptionPane.showMessageDialog(null, "O primeiro número é maior que o segundo");
		} else {
			JOptionPane.showMessageDialog(null, "O primeiro número é menor que o segundo");
		}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}
