package aula1SA;

import javax.swing.JOptionPane;

public class Exercicio5 {
	public static void main (String [] args) {

	int	repetir1=0;
		
	do {
		double peso = Double.parseDouble(JOptionPane.showInputDialog("Entre com o seu peso"));
		double altura = Double.parseDouble(JOptionPane.showInputDialog("Entre com a sua altura"));
		double imc = peso / (altura * altura);
		
		if (imc <= 18.9) {
			 JOptionPane.showMessageDialog(null, "Muito magro. IMC = " + imc);
		} else if(imc <= 24.9) {
			 JOptionPane.showMessageDialog(null, "Padrão. IMC = " + imc);
		} else if(imc <= 29.9) {
			 JOptionPane.showMessageDialog(null, "Sobrepeso. IMC = " + imc);
		} else if(imc <= 39.9) {
			 JOptionPane.showMessageDialog(null, "Obeso. IMC = " + imc);
		} else if(imc >= 40.0) { 
	         JOptionPane.showMessageDialog(null, "Obesidade grave. IMC = " + imc);
	
		}
	
	
	
	
		 repetir1 = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
	 } while(repetir1 == 0 || repetir1 == 2);
	 JOptionPane.showMessageDialog(null, "Programa Finalizado");  

	
	
	
	
	
	
	
	
	
	
}}
