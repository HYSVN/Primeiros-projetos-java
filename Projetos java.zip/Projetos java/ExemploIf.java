package aula1SA;

import javax.swing.JOptionPane;

public class ExemploIf {

	public static void main(String[] args) {


	//	int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com a idade"));
		
		
	/*	
		if (idade >= 18) { 
			JOptionPane.showMessageDialog(null, "Maior");	
		} else {
			JOptionPane.showMessageDialog(null, "Menor");
		}
	*/
		
		/*
		if(idade < 0) {
			JOptionPane.showMessageDialog(null, "Idade inválida!");
		} else if(idade <= 17) {
			JOptionPane.showMessageDialog(null, "Você é Menor: " + idade + " anos.");
		} else if(idade <= 64) {
			JOptionPane.showMessageDialog(null, "Você é Adulto: " + idade + " anos.");
		} else {
			JOptionPane.showMessageDialog(null, "Você é Idoso: " + idade + " anos.");
		}
		
		*/

		

		/*	Salário
		 *  até 1.000         --> 30%
		 *  1000,01 até 2.000 --> 20%
		 *  2000,01 até 3.000 --> 15%
		 *  acima de 3000     --> 10%
		 */
		
		
	/*	
		double valorDoSalario = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor do salário"));
		double aumento = 0;
		double salarioNovo = 0;
		
		
		if (valorDoSalario <= 1000) {
			aumento = valorDoSalario * 0.3;
		} else if(valorDoSalario <= 2000) {
			aumento = valorDoSalario * 0.2;
		} else if(valorDoSalario <= 3000) {
			aumento = valorDoSalario * 0.15;
		} else {
			aumento = valorDoSalario * 0.1;
		}
		
		salarioNovo = valorDoSalario + aumento;
		
		JOptionPane.showMessageDialog(null, "Valor do Salário: " + valorDoSalario + 
											"\nAumento: "        + aumento 		  +
											"\nSalário Novo: "   + salarioNovo);

		*/
		
		/*
		int quantidade =0;
		String resposta = JOptionPane.showInputDialog("Você possui dependentes? S ou N");
		
		if(resposta.equalsIgnoreCase("S")) { 
				quantidade = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade"));
				if(quantidade <= 0) {
					JOptionPane.showMessageDialog(null, "Quantidade Inválida!!!!");
				} else {
					JOptionPane.showMessageDialog(null, "Você possui " + quantidade + " dependentes");
				}
		} else {
			JOptionPane.showMessageDialog(null, "Não possui dependentes");
		}
		
		*/
		
		
		
		
			// !  negação ou inversão
		/*
			String resposta = JOptionPane.showInputDialog("Você é maior? Responda Sim ou Não?");
			
			if (!resposta.equalsIgnoreCase("sim")) { 
				JOptionPane.showMessageDialog(null, "Entrada Proibida");	
			} else {
				JOptionPane.showMessageDialog(null, "Entrada Permitida");
			}
		*/
		
		
		
		boolean resultado = true;
		
		if(resultado) {
			JOptionPane.showMessageDialog(null, "Resultado Verdadeiro");
		} else {
			JOptionPane.showMessageDialog(null, "Resultado Falso");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
}}
