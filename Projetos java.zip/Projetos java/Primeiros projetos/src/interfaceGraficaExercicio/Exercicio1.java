package interfaceGraficaExercicio;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Exercicio1 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfValor1;
	private JTextField tfValor2;
	private JTextField tfTotal;

	
	int valor1,valor2,total;
	
	
	
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Exercicio1 frame = new Exercicio1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Exercicio1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 400);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblExercicio = new JLabel("Exercício 1");
		lblExercicio.setHorizontalAlignment(SwingConstants.CENTER);
		lblExercicio.setFont(new Font("Arial", Font.BOLD, 14));
		lblExercicio.setBounds(189, 24, 114, 23);
		contentPane.add(lblExercicio);
		
		JLabel lblValor1 = new JLabel("Valor 1");
		lblValor1.setFont(new Font("Arial", Font.PLAIN, 13));
		lblValor1.setHorizontalAlignment(SwingConstants.CENTER);
		lblValor1.setBounds(44, 100, 71, 23);
		contentPane.add(lblValor1);
		
		JLabel lblValor2 = new JLabel("Valor 2");
		lblValor2.setFont(new Font("Arial", Font.PLAIN, 13));
		lblValor2.setHorizontalAlignment(SwingConstants.CENTER);
		lblValor2.setBounds(201, 100, 71, 23);
		contentPane.add(lblValor2);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Arial", Font.PLAIN, 13));
		lblTotal.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotal.setBounds(339, 100, 71, 23);
		contentPane.add(lblTotal);
		
		tfValor1 = new JTextField();
		tfValor1.setHorizontalAlignment(SwingConstants.CENTER);
		tfValor1.setBounds(44, 155, 71, 38);
		contentPane.add(tfValor1);
		tfValor1.setColumns(10);
		
		tfValor2 = new JTextField();
		tfValor2.setHorizontalAlignment(SwingConstants.CENTER);
		tfValor2.setColumns(10);
		tfValor2.setBounds(201, 155, 71, 38);
		contentPane.add(tfValor2);
		
		tfTotal = new JTextField();
		tfTotal.setEditable(false);
		tfTotal.setHorizontalAlignment(SwingConstants.CENTER);
		tfTotal.setColumns(10);
		tfTotal.setBounds(339, 155, 71, 38);
		contentPane.add(tfTotal);
		
		JButton btnMais = new JButton("+");
		btnMais.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valor1= Integer.parseInt(tfValor1.getText ());
				valor2= Integer.parseInt(tfValor2.getText ());
				total = valor1 + valor2;
				
				tfTotal.setText (String.valueOf(total));
		
			}
		});
		btnMais.setFont(new Font("Arial", Font.PLAIN, 18));
		btnMais.setBounds(44, 230, 71, 32);
		contentPane.add(btnMais);
		
		JButton btnMenos = new JButton("-");
		btnMenos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valor1= Integer.parseInt(tfValor1.getText ());
				valor2= Integer.parseInt(tfValor2.getText ());
				total = valor1 - valor2;
				
				tfTotal.setText (String.valueOf(total));
			}
		});
		btnMenos.setFont(new Font("Arial", Font.PLAIN, 18));
		btnMenos.setBounds(151, 230, 71, 32);
		contentPane.add(btnMenos);
		
		JButton btnVezes = new JButton("X");
		btnVezes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valor1= Integer.parseInt(tfValor1.getText ());
				valor2= Integer.parseInt(tfValor2.getText ());
				total = valor1 * valor2;
				
				tfTotal.setText (String.valueOf(total));
			}
		});
		btnVezes.setFont(new Font("Arial", Font.PLAIN, 18));
		btnVezes.setBounds(258, 230, 71, 32);
		contentPane.add(btnVezes);
		
		JButton btnDivisao = new JButton("/");
		btnDivisao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				valor1= Integer.parseInt(tfValor1.getText ());
				valor2= Integer.parseInt(tfValor2.getText ());
				total = valor1 / valor2;
				
				tfTotal.setText (String.valueOf(total));
			}
		});
		btnDivisao.setFont(new Font("Arial", Font.PLAIN, 18));
		btnDivisao.setBounds(361, 230, 71, 32);
		contentPane.add(btnDivisao);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			tfValor1.setText(null);
			tfValor2.setText(null);
			tfTotal.setText(null);
			}
		});
		btnLimpar.setFont(new Font("Arial", Font.PLAIN, 13));
		btnLimpar.setBounds(133, 304, 89, 23);
		contentPane.add(btnLimpar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.setFont(new Font("Arial", Font.PLAIN, 13));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int num =JOptionPane.showConfirmDialog(contentPane, "Deseja Sair?", "Sim", JOptionPane.YES_NO_OPTION);
				if(num == 0) {
					
			
					System.exit(0);
				}	}
			
		});
		btnSair.setBounds(276, 304, 89, 23);
		contentPane.add(btnSair);
	}
	
		
	
		
	
	

	
}
