package novembro;

import java.util.Random;

public class VEexercicio3 {

	public static void main(String[] args) {

		int numero[] = new int [10];
		
		System.out.println("Posição:\tNúmero:");
		System.out.println("--------------------------------------------------");
		
		Random objeto = new Random(); 

		
		for (int i = 0; i <= 100; i++) {
		
			numero[i] = objeto.nextInt(101);
		
			  System.out.println((i) + "\t" + "\t" + numero[i] );
	
	}

}
}