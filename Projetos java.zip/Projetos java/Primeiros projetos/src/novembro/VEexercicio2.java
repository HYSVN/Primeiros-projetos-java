package novembro;

import java.util.Random;

public class VEexercicio2 {
	public static void main (String [] args) {

	

		int[] vetor = new int[10];

		Random random = new Random();

		for (int i = 0; i < 10; i++) {
		    vetor[i] = random.nextInt(101); 
		}

		System.out.print("Os números na sua ordem original são: {");
		for (int i = 0; i < 10; i++) {
		    System.out.print(vetor[i]);
		    if (i < 9) {
		        System.out.print(", "); 
		    }
		}
		System.out.println("}");

		
		System.out.print("Os numeros na sua ordem inversa são: {");
		for (int i = 9; i >= 0; i--) {
		    System.out.print(vetor[i]);
		    if (i > 0) {
		        System.out.print(", "); 
		    }
		}
		System.out.println("}");
		
			 
			 
		 }	
}
