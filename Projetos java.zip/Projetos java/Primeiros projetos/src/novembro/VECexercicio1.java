package novembro;

import java.util.Random;

public class VECexercicio1 {

	public static void main(String[] args) {
		
		
		int[] vetor = new int[15];

	
		Random objeto = new Random();

		
		for (int i = 0; i < 15; i++) {
		    vetor[i] = objeto.nextInt(51); 		}

	
		System.out.print("Os números são: {");
		for (int i = 0; i < 15; i++) {
		    System.out.print(vetor[i]);
		    if (i < 14) {
		        System.out.print(", "); 
		    }
		}
		System.out.println("}");

		int soma = 0;
		int contador = 0;
		for (int numero : vetor) {
		    soma += numero;
		    contador++; 
		}
		System.out.println("A soma dos números é: " + soma);

		double media = (double) soma / contador; 
		System.out.println("A média dos números é: " + media);

		int maior = vetor[0];
		for (int numero : vetor) {
		    if (numero > maior) {
		        maior = numero;
		    }
		}
		System.out.println("O maior número dentro do vetor é: " + maior);

		
		int menor = vetor[0];
		for (int numero : vetor) {
		    if (numero < menor) {
		        menor = numero;
		    }
		}
		System.out.println("O menor número dentro do vetor é: " + menor);
	}

}
