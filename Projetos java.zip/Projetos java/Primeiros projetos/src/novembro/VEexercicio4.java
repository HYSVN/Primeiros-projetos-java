package novembro;

import java.util.Random;

public class VEexercicio4 {

		
	public static void main(String[] args) {


		
		

		int[] idades = new int[20];
		String[] nome = new String[20];

		Random objeto = new Random();

		
		
		String letras = "ABCDEFGHIJKMNOPQRSTUVWXYZABCDEFGHIJKMNOPQRSTUVWXYZABCDEFG";

		for (int i = 0; i < 20; i++) {
			int index = objeto.nextInt(22);
			nome [i] = letras.substring(index , index+5); 	
		    idades[i] = objeto.nextInt(101); 
		     
		}

	
		System.out.println("Id:\tNome:\tAnos:");
		for (int i = 0; i < 20; i++) {
		    System.out.println((i+1) + "\t" + nome[i] + "\t" + idades[i]);
		}

		// O nome e a idade da pessoa mais velha
		int maisVelha = 0;
		String nomeMaisVelha = "";
		for (int i = 0; i < 20; i++) {
		    if (idades[i] > maisVelha) {
		        maisVelha = idades[i];
		        nomeMaisVelha = nome[i];
		    }
		}
		System.out.println("O nome e a idade da pessoa mais velha é: " + nomeMaisVelha + " - " + maisVelha + " anos");

		// O nome e a idade da pessoa mais nova
		int maisNova = 100;
		String nomeMaisNova = "";
		for (int i = 0; i < 20; i++) {
		    if (idades[i] < maisNova) {
		        maisNova = idades[i];
		        nomeMaisNova = nome[i];
		    }
		}
		System.out.println("O nome e a idade da pessoa mais nova é: " + nomeMaisNova + " - " + maisNova + " anos");

	
		int soma = 0;
		for (int i = 0; i < 20; i++) {
		    soma += idades[i];
		}
		int media = soma / 20;
		System.out.println("A média de idade é: " + media + " anos");
	}}


