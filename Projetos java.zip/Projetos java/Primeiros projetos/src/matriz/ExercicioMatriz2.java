package matriz;

public class ExercicioMatriz2 {

	public static void main(String[] args) {

		int numA[][] = new int[6][6];
		int numB[][] = new int[6][6];

		int armaze=0;
		
		System.out.println("MatrizM:");
		System.out.println("-------------------------------------------------");
		System.out.println("_________________________________________________");

		for (int i = 0; i < 6; i++) { // Linha
			for (int j = 0; j < 6; j++) { // Coluna
				
				numA[i][j] = (int)(Math.random() * 21);
				armaze = (int) (Math.random() * 51);

				System.out.print(numA[i][j] + "\t" + "| ");
		
		
	}
			System.out.println();
			System.out.println("_________________________________________________");
			
		}
			
		
		System.out.println("Número gerado:");
		System.out.println(armaze);
		System.out.println();
		System.out.println();
		
	
	System.out.println("Matriz Resultante:");
	System.out.println("-------------------------------------------------");

	
	for (int i = 0; i < 6; i++) { // Linha
		for (int j = 0; j < 6; j++) { // Coluna
	
	numB[i][j] = armaze * numA [i] [j];
	System.out.print(numB[i][j] + "\t" + "| ");		
			
			
			
			
		}
			
	
			
		System.out.println();
		System.out.println("_________________________________________________");
			
							
}
			
			}
	}
