package matriz;

import java.util.Random;

import javax.swing.JOptionPane;

public class ExemploMatriz {

	public static void main(String[] args) {

	/*	for (int i = 1; i <= 3; i++) {
			System.out.println("I: " + i);
			System.out.println("J: ");
			for (int j = 1; j <= 5; j++) {
				System.out.print(j + " - ");
			}
			System.out.println();
			System.out.println("-------------------");
		}
		
		/*
		
		int lin  = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de linhas"));
		int col = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de colunas"));
		
		int matriz[][] = new int[lin][col];
		
		for (int i = 0; i < lin; i++) {
			for (int j = 0; j < col; j++) {
				matriz[i][j] = (int)(Math.random() * 10);
				System.out.print(matriz[i][j] + " - ");
			}
			System.out.println();
			System.out.println("------------------");
		}
	
		
		*/
		// Exemplo de Matriz:
		
	
		
		int linhas  = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de linhas"));
		int colunas = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de colunas"));
		
		int idade[][] = new int[linhas][colunas];
		String nome[][] = new String[linhas][colunas];
		double valor[][] = new double[linhas][colunas];
		boolean atualizar[][] = new boolean[linhas][colunas];
		
		Random objeto = new Random(); // instanciação de um objeto da classe Random
		String letras = "ABCDEFGHIJKLMNOPQRSTUVXWYZ";
		
		System.out.println("------------------------------");
		for (int i = 0; i < linhas; i++) { // Linha
				for (int j = 0; j < colunas; j++) { // Coluna
					int index =  objeto.nextInt(22);
					nome[i][j] = letras.substring(index,index + 5);
					idade[i][j] = objeto.nextInt(91);
					valor[i][j] = (int)(Math.random() * 501);
					if(valor[i][j] < 150) {
						atualizar[i][j] = true;
					}
					System.out.print(nome[i][j] + " | ");
				}
			System.out.println();
			System.out.println("-----------------------");
		}
		
		System.out.println();
		System.out.println();
		System.out.println("-------------");
		
		for (int i = 0; i < linhas; i++) {
			for (int j = 0; j < colunas; j++) {
				System.out.print(idade[i][j] + " | ");
			}
			System.out.println();
			System.out.println("-------------");
		}
		
		System.out.println();
		System.out.println();
		System.out.println("-----------------------");
		
		for (int i = 0; i < linhas; i++) {
			for (int j = 0; j < colunas; j++) {
				System.out.print(valor[i][j] + " | ");
			}
			System.out.println();
			System.out.println("-----------------------");
		}
		
		System.out.println();
		System.out.println();
		System.out.println("-----------------------");
		
		for (int i = 0; i < linhas; i++) {
			for (int j = 0; j < colunas; j++) {
				System.out.print(atualizar[i][j] + " | ");
			}
			System.out.println();
			System.out.println("-----------------------");
		}
		
		
		
		
		
	
	}

}
