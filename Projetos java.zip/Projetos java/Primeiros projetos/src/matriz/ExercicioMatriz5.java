package matriz;

import java.util.Random;

import javax.swing.JOptionPane;

public class ExercicioMatriz5 {

	public static void main(String[] args) {
		
			int[][] matriz = new int[10][10];
			Random objeto = new Random();
	      
	        boolean enc = false;

	        System.out.println("MatrizM:");
				System.out.println("---------------------------------------------------------------------------------");
				System.out.println("_________________________________________________________________________________");
			
	        for (int i = 0; i < 10; i++) {
	            for (int j = 0; j < 10; j++) {
	                matriz[i][j] = objeto.nextInt(101); 
	                System.out.print(matriz[i][j] + "\t" + "| ");
	            }
	            
	            System.out.println();
				System.out.println("_________________________________________________________________________________");
	        }

	        int num = Integer.parseInt(JOptionPane.showInputDialog("Qual número deseja consultar?"));
	        for (int i = 0; i < 10; i++) {
	            for (int j = 0; j < 10; j++) {
	                if (num == matriz[i][j]) {
	                    System.out.println("Número encontrado na posição: linha " + i + ", coluna " + j);
	                    enc = true;
	                }
	            }
	        }

	        if (!enc) {
	            System.out.println("Número não encontrado na matriz.");
	        }
	    }
	}
			
		
		
		
		
		
		
		
		
		
	