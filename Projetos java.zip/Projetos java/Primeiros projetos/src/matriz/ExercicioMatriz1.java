package matriz;



public class ExercicioMatriz1 {

	public static void main(String[] args) {

		
		
		int numA[][] = new int[4][6];
		int numB[][] = new int[4][6];
		
		System.out.println("MatrizM:");
		System.out.println("-------------------------------------------------");

		
		for (int i = 0; i < 4; i++) { // Linha
			for (int j = 0; j < 6; j++) { // Coluna
			
			
				
				numA[i][j] = (int)(Math.random() * 21);
				numB[i][j] = (int)(Math.random() * 21);
		System.out.print(numA[i][j] + "\t" + "| ");
		
			}
			System.out.println();
			System.out.println("_________________________________________________");
		
		}
		System.out.println();
		System.out.println();
		System.out.println("MatrizN:");
		System.out.println("-------------------------------------------------");
		
		for (int i = 0; i < 4; i++) { // Linha
			for (int j = 0; j < 6; j++) { // Coluna
				System.out.print(numB[i][j] + "\t" + "| ");
			
			}
			System.out.println();
			System.out.println("_________________________________________________");
		}
		System.out.println();
		System.out.println();
		System.out.println("Produto entre as Matrizes:");
		System.out.println("-------------------------------------------------");
		
			for (int i = 0; i < 4; i++) { 
				for (int j = 0; j < 6; j++) { 
		int produtoresu = numA[i][j]*numB[i][j];
		System.out.print(produtoresu + "\t" + "| ");
		
	}
				System.out.println();
				System.out.println("_________________________________________________");
			}
		
	}}
