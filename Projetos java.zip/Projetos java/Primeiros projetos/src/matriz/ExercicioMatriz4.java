package matriz;

import javax.swing.JOptionPane;

public class ExercicioMatriz4 {

	public static void main(String[] args) {

		
		int lin  = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de linhas"));
		int col = Integer.parseInt(JOptionPane.showInputDialog("Entre com o número de colunas"));
		int soma = 0;
		int matriz[][] = new int[lin][col];
		
		   	System.out.println("_________________________________________________");

		
		for (int i = 0; i < lin; i++) {
			for (int j = 0; j < col; j++) {
				matriz[i][j] = (int)(Math.random() * 21);
				soma += matriz[i][j];
				System.out.print(matriz[i][j] + "\t" + " | ");
			}
			System.out.print( "=" + soma);
			System.out.println();
			soma =0;
			System.out.println("_________________________________________________");
			
		}
		
		
		
	}

}
