package interfaceGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Tela extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfDatadeNascimento;
	private JTextField tfSobrenome;
	private JTextField tfNome;
	private JTextField tfResposta;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tela frame = new Tela();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tela() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(500, 500, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Primeiro programa");
		lblTitulo.setFont(new Font("Sylfaen", Font.ITALIC, 30));
		lblTitulo.setForeground(new Color(255, 0, 255));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(10, 11, 414, 42);
		contentPane.add(lblTitulo);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Arial", Font.PLAIN, 14));
		lblNome.setBounds(10, 82, 153, 32);
		contentPane.add(lblNome);
		
		JLabel lblSobrenome = new JLabel("Sobrenome");
		lblSobrenome.setFont(new Font("Arial", Font.PLAIN, 14));
		lblSobrenome.setBounds(10, 163, 153, 32);
		contentPane.add(lblSobrenome);
		
		JLabel lblDatadeNascimento = new JLabel("Data de Nascimento");
		lblDatadeNascimento.setFont(new Font("Arial", Font.PLAIN, 14));
		lblDatadeNascimento.setBounds(10, 244, 153, 32);
		contentPane.add(lblDatadeNascimento);
		
		tfDatadeNascimento = new JTextField();
		tfDatadeNascimento.setBounds(173, 245, 235, 32);
		contentPane.add(tfDatadeNascimento);
		tfDatadeNascimento.setColumns(10);
		
		tfSobrenome = new JTextField();
		tfSobrenome.setColumns(10);
		tfSobrenome.setBounds(143, 164, 265, 32);
		contentPane.add(tfSobrenome);
		
		tfNome = new JTextField();
		tfNome.setColumns(10);
		tfNome.setBounds(120, 83, 288, 32);
		contentPane.add(tfNome);
		
		JButton btnConfirmar = new JButton("Confirmar");
		btnConfirmar.setBounds(10, 368, 89, 32);
		contentPane.add(btnConfirmar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.setBounds(120, 368, 89, 32);
		contentPane.add(btnLimpar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num =JOptionPane.showConfirmDialog(contentPane, "Deseja Sair?", "Sim", JOptionPane.YES_NO_OPTION);
				if(num == 0) {
					
			
					System.exit(0);
				}	}
		});
		btnSair.setBounds(229, 368, 89, 32);
		contentPane.add(btnSair);
		
		tfResposta = new JTextField();
		tfResposta.setBounds(10, 301, 403, 42);
		contentPane.add(tfResposta);
		tfResposta.setColumns(10);
	}
}
