package setembro;



public class Ativ4 {

	public static void main(String[] args) {

		
		
 		
		
		//int numeros = {1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1};
		//numbers = {1024, 512, 256, 128, 64, 32, 16, 8, 4, 2, 1} ;

		/* for (int i = 0; i < numbers.length; i++) {
	            int value = (int) Math.pow(2, i);
	            System.out.println(numeros[i] + " - " + value);
	*/
		int dividindo=0;
		
		for(int i = 1; i <=1024; i*=2) {
			
			dividindo = 1024/i;
			
			System.out.println( i + "-" + dividindo );
		}
			
 		
 		
}	
	}
 		
 	
	

	
	


