package setembro;

import java.util.Random;


public class Vexercicio1 {

	public static void main(String[] args) {

		
		double nota1[] = new double [40];
		double nota2[] = new double [40];
		String nome[] = new String [40];
        double media[] = new double [40];
        String situacao[] = new String [40];
        
		Random objeto = new Random(); 
		String letras = "ABCDEFGHIJKMNOPQRSTUVWXYZABCDEFGHIJKMNOPQRSTUVWXYZ";
		
		System.out.println("Id:\tNome:\tNota 1:\tNota 2:\tMédia: \tSituação:");
		System.out.println("--------------------------------------------------");
		
		for (int i = 0; i < 40; i++) {
			
		int index = objeto.nextInt(41);
		nome [i] = letras.substring(index , index+5); 	
		nota1[i] = objeto.nextInt(11);
		nota2[i] = objeto.nextInt(11);
		media[i] = (nota1[i] + nota2[i])/2;
		
		
		if(media[i] >= 7.0) {
				situacao[i] = "Aprovado";
		} else {
				situacao[i] = "Reprovado";
		}
		System.out.println((i+1) + "\t" + nome[i] + "\t" + nota1[i] + "\t" + nota2[i] + "\t" + media[i] + "\t" + situacao[i]);
}	
			
	
}
			}
	

		
		
		
		
		
	


