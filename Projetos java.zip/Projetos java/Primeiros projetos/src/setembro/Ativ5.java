package setembro;

import javax.swing.JOptionPane;

public class Ativ5 {
 public static void main (String[] args) {
	
	 
	 int repetir=1;
	 
	do {

	
	     int a = Integer.parseInt(JOptionPane.showInputDialog("Numero"));

	     int b = Integer.parseInt(JOptionPane.showInputDialog("Numero"));

	     System.out.println("No intervalo de " + a + " até " + b + ", os números são: ");

	     for (int i = a + 1; i < b; i++) {
	       System.out.print(i + ", ");
	     }

	     System.out.println();
 


            repetir = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
            } while(repetir == 0 || repetir == 2);
            JOptionPane.showMessageDialog(null, "Programa Finalizado");  
	
	
	
	
	
	
	
	
	
	
	
	
	
}}
