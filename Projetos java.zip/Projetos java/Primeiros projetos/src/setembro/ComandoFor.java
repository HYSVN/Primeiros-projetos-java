package setembro;

public class ComandoFor {

	public static final String out = null; 
		// &&(e) ||(ou) !(não/negaçâo) 

		// Estrutura de repetiçâo
		// * while e do-while
		// * &&(e) ||(OU)  !(Nâo/negaçâo)
		// * 
		// * Seleçâo de canditatos
		// *  idade < 18 e cursando técnico
		// * 
		//  int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com a idade"));
		/*  String resposta = JOptionPane.showInputDialog("Está cursando técnico? S ou N?);
		 *  String qi = JOptionPane.showInputDialog("Você tem QI? S ou N?);
		 * 
		 *  if (idade < 18) && (respota.equalsIgnoreCase("s")){
		 *  JOptionPane.showMessageDialog(null, "candidato apto");
		 *  } else {
		 *  JOptionPane.showMessageDialog(null, "candidato reprovado");
		 *  }
		 * 
		 * int repitir = 0;
		 * do {
		 *  int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com a idade));
		 *  String resposta = JOptionPane.showInputDialog("Está cursando técnico? S ou N?);
		 *  if (idade < 18) && (respota.equalsIgnoreCase("s")){
		 *  JOptionPane.showMessageDialog(null, "candidato apto");
		 *  } else if (idade >= 18 && respota.equalsIgnoreCase("n")) {
		 *  JOptionPane.showMessageDialog(null, "candidato reprovado pela idade e curso");
		 *  } else if ( respota.equalsIgnoreCase("n")) {
		 *   JOptionPane.showMessageDialog(null, "candidato reprovado pelo curso");
		 *  } else {
		 *    JOptionPane.showMessageDialog(null, "candidato reprovado pela idade" + idade);
		 *  }
		 * 
		 * repetir = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JoptionPane.YES_NO_CANCEL_OPTION);
		 * } while(repetir == 0 || repetir == 2):
		 * JOptionPane.showMessageDialog(null, "Programa Encerrado"); 
		 */

		// dia 20/09
		
		//int i = 0;
		
		//contador
		//i++;     //incremento
		
		// i += 10;
		 
		 //i-- //decremento
		 //i-= 5;
		 
		 //estrutura de repetição
		 //for
	
	/*	 for(int i=1; i<10; i++) {
		     System.out.print("i=1" + " - ");
		}
		
	    System.out.println();
		for(int i=0; i<100; i+=10) {
		     System.out.print(i + " - ");
		}
		
		System.out.println();
		for(int i=100; i<200; i+=20) {
		     System.out.println(i + " - ");
		}
		
		System.out.println();
		for(int i=100; i>0; i-=10) {
		     System.out.print(i + " - ");
		}
		
		System.out.println();
		for(int i=1; i<10; i++) {
		     System.out.println(i*i + " - ");
		}
		
		
		//acumulador
		
		int soma = 0;
		for(int i=1; i<=10; i++) {
		     System.out.print("i = " + i +  " - ");
		   soma += i;
		System.out.println("Soma = " + soma);
		}
		System.out.println();
		
		int total = 0;
		int maior = 0;
		int menor = 100;
		for(int i = 1; i <=10; i++) {
		    int numero = (int) (Math.random() * 101);
		    System.out.println(i + "°) " + numero);
		    total += numero;
		   maior = Math.max(maior, numero);
		   menor = Math.min(menor, numero);
		
		}
		
		System.out.println("Total = " + total);
		System.out.println("Maior = " + maior);
		System.out.println("Menor = " + menor);
	*/
	

	

}
	
