package setembro;

import java.util.Random;

public class Vexercicio3 {
	
	public static void main(String[] args) {
	
	String nome[] = new String [50];
	int valor [] = new int [50];


	Random objeto = new Random(); 
	String letras = "ABCDEFGHIJKMNOPQRSTUVWXYZABCDEFGHIJKMNOPQRSTUVWXYZ";

	System.out.println("Id:\tNome:\tNúmeros:");
	System.out.println("-------------------------------------------");

	for (int i = 0; i < 50; i++) {
		int index = objeto.nextInt(22);
		nome [i] = letras.substring(index , index+5); 	
		valor[i] = (int) (Math.random() * 101);

	    System.out.println((i+1) + "\t" + nome[i] + "\t" + valor[i] + "\t");
	}
	    int numB [] = new int [20];

    for (int i = 0; i < 20; i++) {
	     int sorteio2 =  objeto.nextInt(50);
	     numB[i] = valor[sorteio2];

    }  
         System.out.println("-------------------------------------------");
         System.out.println("Sorteio");
    for (int num: numB) {
         System.out.println("\t" + num); 
    }



}

}

