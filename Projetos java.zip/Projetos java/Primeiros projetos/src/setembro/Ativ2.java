package setembro;

import javax.swing.JOptionPane;

public class Ativ2 {

	public static void main(String[] args) {
		int repetir1 = 0;
		String dados = "";
		do {
		
		int numero = Integer.parseInt(JOptionPane.showInputDialog("Numero"));
		
		for(int i=10; i>=1;i--) {
		//System.out.println(numero + "x" + i + "=" + (numero*i));
			dados += numero + "x" + i + "=" + (numero*i) + "\n";
		
		}
		//JOptionPane.showMessageDialog(null, numero + "x" + i + "=" + (numero*i));
		JOptionPane.showMessageDialog(null, dados);
		
		 repetir1 = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
		 } while(repetir1 == 0 || repetir1 == 2);
		 JOptionPane.showMessageDialog(null, "Programa Finalizado");  
	}

}
