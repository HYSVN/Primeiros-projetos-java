package setembro;

import java.util.Random;

public class Vexercicio5 {

	public static void main(String[] args) {
	
		String nome[] = new String [20];
		double salario[]= new double [20];
		double mediaS = 0;
		double total=0;
		
		Random objeto = new Random(); 
		String nomes = "ABCDEFGHIJKMNOPQRSTUVWXYZABCDEFGHIJKMNOPQRSTUVWXYZ";
		 System.out.println("Id:\tNome:\tSalário:");
		
		
		for (int i = 0; i < 20; i++) {
			int index = objeto.nextInt(22);
			nome [i] = nomes.substring(index , index+5); 	
			salario[i] = (int) (Math.random() * 3001);
		    total+=salario[i];
			
			  System.out.println((i+1) + "\t" + nome[i] + "\t" + salario[i] + "\t");
		    }
		
			  mediaS= total/20;
			  System.out.println("-------------------------------------------------");
			  System.out.println("Id:\tNome:\tMedia:\tSalário:\tSituação:");
			  System.out.println();
			  
			  
		for ( int i= 0; i<20; i++) {
			  if (salario[i] > 1280) {
					System.out.println((i + 1) + "\t" + nome[i]  + "\t" + mediaS + "\t" + salario[i] + "\t" + "\t" + "Acima");;
				} else if(salario[i] <= 1280.00 ) {
				    System.out.println((i + 1) + "\t" + nome[i] +  "\t" + mediaS + "\t" + salario[i] +"\t" +  "\t"  +"Menor");
				}
		
		

	}

}
	
	
}
	
			
