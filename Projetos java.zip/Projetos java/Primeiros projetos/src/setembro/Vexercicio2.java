package setembro;

import java.util.Random;

public class Vexercicio2 {

	public static void main(String[] args) {

		
		int vetorA[] = new int [20];
		int vetorB[] = new int [20];
		int vetorC[] = new int [20];
		
		
		Random objeto = new Random(); 

		System.out.println("VetorA: \tVetorB: \tVetorC:");

		for (int i = 0; i < 20; i++) {

			vetorA[i] = objeto.nextInt(11);
			vetorB[i] = objeto.nextInt(11);
			vetorC[i] = (vetorA[i]*vetorB[i]);

			System.out.println(vetorA[i] + "\t" + "X" + "\t" + vetorB[i] + "\t" + "=" + "\t" + vetorC[i] );
		
		
		
		
		
	}

}
         }