package setembro;

import java.util.Random;

import javax.swing.JOptionPane;
 
public class Vexercicio4 {
	
	public static void main(String[] args) {
	
	
	int repetir =0;
	int numero[] = new int [100];
	

	Random objeto = new Random(); 


	System.out.println("Id:\tNúmero:");
	System.out.println("-------------------------------------------");

	for (int i = 0; i < 100; i++) {
	     numero[i] = objeto.nextInt(101);
	  

	System.out.println((i+1) + "\t" + numero[i] );
	}

do {		
int num = Integer.parseInt(JOptionPane.showInputDialog("Qual número deseja consultar?"));
	if(num >=1 && num <=100) {
		for (int i = 0; i < 100; i++) {
			if (num == numero[i] ) {
				System.out.println();
				System.out.println("-------------------------------------------");
				System.out.println((i+1) + "\t" + numero[i]);
		
			}
		}
	
			} else {
					System.out.println();
					System.out.println("-------------------------------------------");
					System.out.println(num + " é inválido");
	
	}
	 repetir = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
 } while(repetir == 0 || repetir == 2);
 JOptionPane.showMessageDialog(null, "Programa Finalizado");  	
	
	
	
	
	
}
		}
	
