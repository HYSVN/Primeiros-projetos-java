package setembro;

import javax.swing.JOptionPane;

public class Ativ3 {

	public static void main(String[] args) {
        
		int repetir1=0;
		
	do {
	
		//Declaração das variáveis
        int soma = 0;        
        int maior50=0;       
        int maioresouigual50 = 0;
        int menores50 = 0;        
        int menor50=100;
        String dadosmaior50 = "";
        String dadosmenor50 = "";
       
        //Estrutura de repetição - gera 20 numeros aleatorios
        for(int i = 1; i <=20; i++) {
        	int numero = (int) (Math.random() * 101);//função random() gera numeros entre 0 e 100
        	
        	System.out.println(i + "°) " + numero);
        	
        	soma += numero;
        
        	maior50 = Math.max(maior50,numero);
        	menor50=Math.min(menor50,numero);

        
        	if (numero >=50 ) {
        		maioresouigual50 += 1;
        		dadosmaior50 += numero + ", ";
        	}
        	// pode retirar (numero < 50) se quiser. Pq ele já cai no proximo se não entrar no primeiro
        	else if(numero < 50) {
        		menores50 +=1;
        		dadosmenor50 += numero + ",";
        	}    
        	
        	/* Se não quiser que apareça os numeros
        	if (numero >=50 ) {
        		maioresouigual50 += 1;
        	}        	
        	else{
        		menoresouigual50 +=1;
        	} */   
        	
        }

     
        System.out.println("Maior = " + maior50);
        System.out.println("Menor = " + menor50);
        System.out.println("Os números menores que 50 são: " + dadosmenor50 );//menoresouigual50
        System.out.println("Quantidade de números menores que 50: " + menores50); 
        System.out.println("Os números maiores ou iguais a 50 são: " + dadosmaior50 ); //maioresouigual50
        System.out.println("Quantidade de números maiores ou iguais a 50: " + maioresouigual50 );
        System.out.println("Soma dos numeros = " + soma);
		
        repetir1 = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
	 } while(repetir1 == 0 || repetir1 == 2);
	 JOptionPane.showMessageDialog(null, "Programa Finalizado");  

        
	}
	
}









