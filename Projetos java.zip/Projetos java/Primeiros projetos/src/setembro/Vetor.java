package setembro;

import java.util.Random;

import javax.swing.JOptionPane;

public class Vetor {

	public static void main(String[] args) {
	
		int repetir =0;
		int idade[] = new int [20];
		String nome[] = new String [20];
        double valor[] = new double [20];
		boolean atualizar[] = new boolean[20];
		
		Random objeto = new Random(); 
		String letras = "ABCDEFGHIJKMNOPQRSTUVWXYZ";
		
		System.out.println("Id:\tNome:\tIdade:\tValor:\tAtualizar");
		System.out.println("-------------------------------------------");
		
		for (int i = 0; i < 20; i++) {
			
		int index = objeto.nextInt(22);
		nome [i] = letras.substring(index , index+5); 	
		idade[i] = objeto.nextInt(91);
		valor[i] = (int) (Math.random() * 501);
		
		if(valor[i] < 250) {
			atualizar[i] = true;
		}
		System.out.println((i+1) + "\t" + nome[i] + "\t" + idade[i] + "\t" + valor[i] + "\t" + atualizar[i]);
}	
	do {		
	int num = Integer.parseInt(JOptionPane.showInputDialog("Qual número deseja consultar?"));
		if(num >=1 && num <=20) {
			System.out.println();
			System.out.println("-------------------------------------------");
			System.out.println((num) + "\t" + nome[num-1] + "\t" + idade[num-1] + "\t" + valor[num-1] + "\t" + atualizar[num-1]);
		} else {
			System.out.println();
			System.out.println("-------------------------------------------");
			System.out.println(num + " é inválido");
		}
		 repetir = JOptionPane.showConfirmDialog(null, "Deseja executar novamente?", "Sair", JOptionPane.YES_NO_OPTION);
	 } while(repetir == 0 || repetir == 2);
	 JOptionPane.showMessageDialog(null, "Programa Finalizado");  

	
	}

}
