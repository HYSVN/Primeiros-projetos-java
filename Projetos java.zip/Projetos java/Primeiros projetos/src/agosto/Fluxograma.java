package agosto;

import javax.swing.JOptionPane;

public class Fluxograma {
	public static void main (String args[] ) {


	int idade = Integer.parseInt(JOptionPane.showInputDialog("Entre com tamanho da peça")); 
	
	
	if (idade >=18) {
		JOptionPane.showMessageDialog(null, "Maior");
	} else {
		JOptionPane.showMessageDialog(null, "Menor");
	}
	
	 
	
	/*>= maior igual
	<= menor igual 
	!= diferente
	*/
	}}