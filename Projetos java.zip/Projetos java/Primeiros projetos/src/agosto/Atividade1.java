package agosto;

import javax.swing.JOptionPane;

public class Atividade1 {
	public static void main (String args[]) {


String nomeDoProduto= JOptionPane.showInputDialog("Entre com o nome do produto");
    
   int quantidade= Integer.parseInt(JOptionPane.showInputDialog("DIgite a quantidade comprada"));
   double precoUnitario= Double.parseDouble(JOptionPane.showInputDialog("Entre o preço unitário do produto"));

   double ValorTotal= quantidade * precoUnitario;
   JOptionPane.showMessageDialog(null, "Nome do produto: "     +  nomeDoProduto +
		                               "\nQuantidade: "        +  quantidade   + 
		                               "\nPreco unitário: R$ " + precoUnitario  +
		                               "\nValor total: R$ "    + ValorTotal);


















}}
