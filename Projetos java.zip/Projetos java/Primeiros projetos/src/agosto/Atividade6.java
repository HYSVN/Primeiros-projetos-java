package agosto;

import javax.swing.JOptionPane;

public class Atividade6 {
	public static void  main (String args[]) {

	
	
	
		String nomeDoProduto = JOptionPane.showInputDialog("Entre com o nome do produto");
		int    quantidade = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade comprada"));
		double precoUnitario = Double.parseDouble(JOptionPane.showInputDialog("Entre com o preço unitário do produto"));
		double porcentagem = 30;
		double subTotal = quantidade * precoUnitario;

		double acrescimo = subTotal * porcentagem/100;
        double totalaPagar= subTotal + (subTotal * porcentagem / 100);
        
        JOptionPane.showMessageDialog(null,  "Nome do produto: "                             + nomeDoProduto +
        		                             "\nPreço unitário: R$ "                         + precoUnitario +
        		                             "\nQuantidade: "                                + quantidade    +
        		                             "\nSub-Total: R$ "                              + subTotal      +
        		                             "\nPorcentagem de lucro: "                      + porcentagem   + "%" +
        		                             "\nAcréscimo: R$ "                              + acrescimo     + 
        		                             "\nTotal a Pagar: R$ "                          + totalaPagar);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}