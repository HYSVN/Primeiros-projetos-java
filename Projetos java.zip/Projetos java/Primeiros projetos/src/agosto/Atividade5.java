package agosto;

import javax.swing.JOptionPane;

public class Atividade5 {
	public static void main (String args []) {


	
		 double money = Double.parseDouble(JOptionPane.showInputDialog("Dolár"));
         
		 double dolarEmReais = money * 5.22;
       //int se for colocar numero inteiro		  
		  

		  JOptionPane.showMessageDialog(null, "Doláres: U$ "        +  money   + 
                                              "\nEm reais: R$ "     + dolarEmReais);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}