package agosto;

import javax.swing.JOptionPane;

//linha de comentario uma linha antes ou no final da linha 

public class Projeto1 {
    public static void main (String args[]         ) {
    	


 /*linha de comentario tem que estar dentro das chaves
  * dia 02/08/2023
  */

    //int idade 
    
   /*String endereco= "Aparecida";  
    String nome= "Hyan Vinicius";
   
    String idade= "16";
    
    //int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade") )
    int quantidade= Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade"));
    int idade = Integer.parseInt(JOptionPane.showInputDialog("Digite sua idade") );
    
    System.out.print("Nome: " + nome + 
    		"\nEndereço: " + endereco + 
    		"\nVocê tem: " + idade +  " anos. ");
  
    		
    nome = JOptionPane.showInputDialog("Digite seu nome");
    
    endereco = JOptionPane.showInputDialog("Digite seu endereço");

    idade = JOptionPane.showInputDialog("Sua idade");
    
    JOptionPane.showMessageDialog(null, "Nome: "   + nome   +   
            "\nEndereço: " + endereco +
            "\nQuantidade: " + quantidade +
            "\nVocê tem " + idade + " anos.");*/
 
    String nomeDoProduto= JOptionPane.showInputDialog("Entre com o nome do produto");
    
    int quantidade= Integer.parseInt(JOptionPane.showInputDialog("DIgite a quantidade comprada"));
    double precoUnitario= Double.parseDouble(JOptionPane.showInputDialog("Entre o preço unitário do produto"));

   double ValorTotal= quantidade * precoUnitario;
   JOptionPane.showMessageDialog(null, "Nome do produto: "     +  nomeDoProduto +
		                               "\nQuantidade: "        +  quantidade   + 
		                               "\nPreco unitário: R$ " + precoUnitario  +
		                               "\nValor total: R$ "    + ValorTotal);

  
    String nomeDoAluno = JOptionPane.showInputDialog("Digite o nome do aluno");
    
   double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Entre com a 1º nota"));
   double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Entre com a 2º nota"));
   double media = (nota1 + nota2) / 2;
   
		   JOptionPane.showMessageDialog(null, "Nome do aluno: "  + nomeDoAluno +
				                       "\n1º Nota: " + nota1 +
				                       "\n2º Nota: " + nota2 +
				                       "\nMédia:"    + media);
		   
   nomeDoProduto = JOptionPane.showInputDialog("Entre com o nome do produto"); 
   quantidade = Integer.parseInt(JOptionPane.showInputDialog("Digite a quantidade comprada"));
   precoUnitario = Double.parseDouble(JOptionPane.showInputDialog("Entre com o preço unitário do produto"));
   double porcentagem = Double.parseDouble(JOptionPane.showInputDialog("Entre com a porcentagem"));
   
   double subTotal = quantidade * precoUnitario;
   double acrescimo = subTotal * porcentagem/100;
   //double totalPagar = subTotal + acrescimo;
  
   double totalPagar = subTotal + (subTotal * porcentagem/100);
   
   JOptionPane.showMessageDialog(null, "Nome do produto: "         + nomeDoProduto + 
		                               "\nQuantidade: "            + quantidade    + 
		                               "\nPreco unitário:R$ "      + precoUnitario +
		                               "\nSub-total: R$ "          + subTotal      +
		                               "\nAcréscimo: R$ "          + acrescimo     +
		                               "\nPorcentagem:  "          + porcentagem   +
		                               "\nTotal a Pagar total: R$" + totalPagar);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 }}  
