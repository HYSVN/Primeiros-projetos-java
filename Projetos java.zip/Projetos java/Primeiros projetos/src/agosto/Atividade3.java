package agosto;

import javax.swing.JOptionPane;

public class Atividade3 {
	public static void main (String args []) {

	
	
	

        int peso = Integer.parseInt(JOptionPane.showInputDialog("Quantos Kilos"));
        
		int pesoEmGramas = peso * 1000;
      // double se for colocar numero decimal		  
		  

		  JOptionPane.showMessageDialog(null, "Kilos: "        +  peso + "kg"  + 
                                              "\nGramas: "     + pesoEmGramas  + "g");
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}
