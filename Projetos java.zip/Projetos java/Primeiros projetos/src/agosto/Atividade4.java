package agosto;

import javax.swing.JOptionPane;

public class Atividade4 {
	public static void main (String args[]) {


	String nomeDoFuncionario = JOptionPane.showInputDialog("Digite o nome do funcionário");
	
	double horasTrabalhadas = Double.parseDouble(JOptionPane.showInputDialog("Horas trabalhadas")); 
	double valorPorHora = Double.parseDouble(JOptionPane.showInputDialog("Valor ganho por hora"));
	double valoraGanhar = horasTrabalhadas * valorPorHora;
	
	JOptionPane.showMessageDialog(null, "Nome do funncionário: "           + nomeDoFuncionario +  
			                            "\nHoras trabalhadas: "            + horasTrabalhadas  +
			                            "\nQuanto ganha por hora: R$ "     + valorPorHora      +
			                            "\nValor a ganho por dia: R$ "     + valoraGanhar);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}}