package agosto;

import javax.swing.JOptionPane;

public class Atividade2 {
	public static void main (String args  []) {


		  
          int tamanho = Integer.parseInt(JOptionPane.showInputDialog("Metros"));
          
		  double tamanhoEmCentímetros = tamanho * 100;
        //int se for colocar numero inteiro		  
		  

		  JOptionPane.showMessageDialog(null, "Metros: "        +  tamanho   + "m" +
                                              "\nCentímetros: " + tamanhoEmCentímetros + "cm");
	
	
	
	
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	}}
