package Explicacao;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Painel extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblImagem;
	private JLabel lblTitulo;

	
	
	int controle=0;
	private JButton btnAnterior;
	private JButton btnProximo;
	private JButton btnReiniciar;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Painel frame = new Painel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Painel() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 644, 644);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(Color.MAGENTA, 4, true));
		panel.setBounds(10, 11, 608, 88);
		contentPane.add(panel);
		panel.setLayout(null);
		
		lblTitulo = new JLabel("Programa de Imagens");
		lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(202, 11, 226, 66);
		panel.add(lblTitulo);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new LineBorder(new Color(255, 0, 0), 4, true), "Jogo/Game", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(10, 142, 608, 279);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		lblImagem = new JLabel("");
		lblImagem.setHorizontalAlignment(SwingConstants.CENTER);
		lblImagem.setIcon(new ImageIcon("C:\\Users\\aluno\\Downloads\\horaAventura.jpg"));
		lblImagem.setBounds(10, 11, 588, 257);
		panel_1.add(lblImagem);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.CYAN, 4, true));
		panel_2.setBounds(10, 459, 608, 103);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		btnAnterior = new JButton("Anterior");
		btnAnterior.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				controle --;
				validacao();
				exibir();
			}
		});
		btnAnterior.setBounds(50, 34, 89, 39);
		panel_2.add(btnAnterior);
		
		btnProximo = new JButton("Próximo");
		btnProximo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			controle ++;
			exibir();
			validacao();
			}
		});
		btnProximo.setBounds(189, 34, 89, 39);
		panel_2.add(btnProximo);
		
		btnReiniciar = new JButton("Reiniciar");
		btnReiniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				reiniciar();
			}
		});
		btnReiniciar.setBounds(328, 34, 89, 39);
		panel_2.add(btnReiniciar);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num =JOptionPane.showConfirmDialog(contentPane, "Deseja Sair?", "Sim", JOptionPane.YES_NO_OPTION);
				if(num == 0) {
					
			
					System.exit(0);
				}
			}});
		btnSair.setBounds(467, 34, 89, 39);
		panel_2.add(btnSair);
	}
	
	public void reiniciar(){
			
	controle = 0;
	lblImagem.setIcon(null);
	lblTitulo.setText("Programa de Imagens");
	validacao();
	btnReiniciar.setEnabled(false);
}
	
	
	public void exibir() {
	
		lblImagem.setText(null);

		switch (controle) {
	case 1:
		lblTitulo.setText(controle + " -  Hora de Aventura");
		lblImagem.setIcon(new ImageIcon("C:\\Users\\aluno\\Downloads\\horaAventura.jpg"));
		break;
		
	case 2:
		lblTitulo.setText(controle + " -  Hora de Aventura");
		lblImagem.setIcon(new ImageIcon("C:\\Users\\aluno\\Downloads\\frase-para-grupo.jpg"));
		break;
		
	case 3:
		lblTitulo.setText(controle + " -  Hora de Aventura");
		lblImagem.setIcon(new ImageIcon(""));
		break;
	
		}
	
		}

	public void validacao() {
		
		if (controle > 1) {
			btnAnterior.setEnabled(true);
		}
		if (controle <= 1) {
			btnAnterior.setEnabled(false);
		}	
			
		if (controle == 3) {
			btnProximo.setEnabled(false);	
		}
		if (controle < 3) {
			btnProximo.setEnabled(true);
		}
		if (controle >= 1 && controle <= 3) {
			btnReiniciar.setEnabled(true);
		} else {
			btnReiniciar.setEnabled(false);
		}
	}



	
	
}
